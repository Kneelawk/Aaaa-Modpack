#!/usr/bin/env bash

java -jar packwiz-installer-bootstrap.jar -g -s server https://raw.githubusercontent.com/Kneelawk/Aaaa-Modpack/main/pack.toml

java -jar quilt-server-launch.jar nogui

